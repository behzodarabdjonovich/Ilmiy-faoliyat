from pathlib import Path
from datetime import date
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.units import mm
from app.database.models import Letter, Organization
def create_pdf(letter:Letter, org:Organization|None, out:Path)->Path:
    out.parent.mkdir(parents=True,exist_ok=True); styles=getSampleStyleSheet(); story=[]
    if org:
        if org.logo_path and Path(org.logo_path).exists(): story.append(Image(org.logo_path,width=25*mm,height=25*mm))
        story.append(Paragraph(org.full_name, ParagraphStyle('org',parent=styles['Heading2'],alignment=TA_CENTER)))
        details=' | '.join(x for x in [org.address,org.phone,org.email,org.website] if x)
        if details: story.append(Paragraph(details,ParagraphStyle('det',parent=styles['Normal'],alignment=TA_CENTER)))
    story += [Spacer(1,8*mm),Paragraph(f"Sana: {date.today():%d.%m.%Y} &nbsp;&nbsp; № {letter.letter_number or '—'}",styles['Normal']),Spacer(1,5*mm)]
    story.append(Paragraph(letter.recipient,ParagraphStyle('rec',parent=styles['Normal'],alignment=TA_RIGHT)))
    if letter.recipient_person: story.append(Paragraph(letter.recipient_person,ParagraphStyle('rp',parent=styles['Normal'],alignment=TA_RIGHT)))
    story += [Spacer(1,5*mm),Paragraph(f"<b>Mavzu: {letter.subject}</b>",styles['Normal']),Spacer(1,5*mm)]
    for block in letter.content.split('\n'):
        if block.strip(): story += [Paragraph(block.strip().replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Spacer(1,3*mm)]
    story += [Spacer(1,8*mm),Paragraph(f"{letter.signer_position or ''} &nbsp;&nbsp;&nbsp;&nbsp; {letter.signer_name or ''}",styles['Normal'])]
    if letter.attachments: story.append(Paragraph(f"Ilova: {letter.attachments}",styles['Normal']))
    SimpleDocTemplate(str(out),pagesize=A4,rightMargin=20*mm,leftMargin=25*mm,topMargin=18*mm,bottomMargin=18*mm).build(story); return out

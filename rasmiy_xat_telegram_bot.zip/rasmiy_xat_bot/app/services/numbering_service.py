from datetime import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.models import LetterCounter, Organization
async def next_number(s:AsyncSession, organization_id:int)->str:
    org=await s.get(Organization, organization_id)
    if not org: raise ValueError("Organization not found")
    year=datetime.now().year if org.reset_yearly else 0
    async with s.begin():
        q=select(LetterCounter).where(LetterCounter.organization_id==organization_id, LetterCounter.year==year).with_for_update()
        counter=(await s.execute(q)).scalar_one_or_none()
        if counter is None:
            counter=LetterCounter(organization_id=organization_id,year=year,value=0); s.add(counter); await s.flush()
        counter.value+=1
        value=counter.value
    return f"{org.number_prefix}/{value:03d}"

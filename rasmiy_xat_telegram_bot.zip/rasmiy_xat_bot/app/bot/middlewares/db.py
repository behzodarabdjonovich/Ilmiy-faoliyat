from aiogram import BaseMiddleware
from app.database.session import SessionLocal
class DbMiddleware(BaseMiddleware):
    async def __call__(self,handler,event,data):
        async with SessionLocal() as session:
            data['session']=session
            return await handler(event,data)

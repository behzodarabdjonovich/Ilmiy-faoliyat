# Rasmiy Xat Telegram Bot

O‘zbekiston tashkilotlari uchun AI yordamida rasmiy xat yaratish, tahrirlash va DOCX/PDF chiqarishga mo‘ljallangan aiogram 3.x loyihasi.

## Imkoniyatlar
- FSM orqali xat ma'lumotlarini yig‘ish
- OpenAI Responses API orqali o‘zbekcha rasmiy matn
- PostgreSQL + SQLAlchemy async
- Xat versiyalarini saqlash
- DOCX va PDF generatsiyasi
- Admin statistikasi
- Tashkilot va raqamlash uchun DB modellari
- Docker Compose

## Ishga tushirish
1. Python 3.12+ o‘rnating.
2. `.env.example` ni `.env` ga nusxalang va `BOT_TOKEN`, `OPENAI_API_KEY`, `DATABASE_URL`, `ADMIN_IDS` ni kiriting.
3. Lokal: `python -m venv .venv`, virtual muhitni faollashtiring, `pip install -r requirements.txt`.
4. PostgreSQL ishlayotganiga ishonch hosil qiling.
5. Birinchi migrationni yarating: `alembic revision --autogenerate -m "initial"`; so‘ng `alembic upgrade head`.
6. Botni ishga tushiring: `python -m app.main`.

## Docker
`.env` yarating, keyin:
```bash
docker compose up -d --build
docker compose exec bot alembic revision --autogenerate -m "initial"
docker compose exec bot alembic upgrade head
docker compose restart bot
```

## BotFather
Telegram ichida rasmiy BotFather orqali yangi bot yarating va tokenni `.env` dagi `BOT_TOKEN` ga yozing. Tokenni Git'ga yubormang.

## OpenAI
OpenAI API kalitini `.env` dagi `OPENAI_API_KEY` ga yozing. Model `OPENAI_MODEL` bilan boshqariladi. Default qiymat xarajatni nazorat qilish uchun `gpt-5.6-luna`.

## Production
- `.env` va tokenlarni secret managerda saqlang.
- PostgreSQL uchun backup va TLS qo‘llang.
- Botni reverse proxy talab qilmaydigan polling bilan yoki alohida webhook deployment bilan ishlating.
- Loglarda xat matni va API kalitlarini yozmang.
- Fayl storage'ni object storage'ga ko‘chirish mumkin.

## Eslatma
Repo asosiy ishlaydigan MVP va kengaytiriladigan arxitekturani beradi. Tashkilot profilini Telegram orqali to‘liq CRUD qilish, pagination UI, audit-log yozuvlari va yuklab olish statistikasi modelda ko‘zda tutilgan bo‘lsa-da, ularni deployment talablariga mos ravishda kengaytirish mumkin.
